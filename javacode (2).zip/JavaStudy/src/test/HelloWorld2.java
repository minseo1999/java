package test;

public class HelloWorld2 {
	public static void main(String[] args){
	    	
		System.out.println("Hello World22");
		System.out.println("여기다 쓰면 화면에 나타납니다");
	}
}
